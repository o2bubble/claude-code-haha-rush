# AI_NOTES — nodejs 插件排查文档（面向 AI）

本插件是 GUI 插件生态的运行时基础设施：为插件后台进程与 AI Bash 提供 Node.js LTS。
包内**不含** Node 本体——安装后需要你（AI）按本文档完成实际的环境安装。

## 平台检测（读取本文件前必做）

- 先确认当前平台：AI 上下文（系统提示 OS Version 行 / `process.platform`）已自带，
  如果你不知道该跑 `node -p process.platform`（`win32`→Windows、`darwin`→macOS、`linux`→Linux）。
- 本插件 manifest `platforms: ["windows","macos","linux"]`——全平台支持。
- **差异只在文件格式/验证路径/目录结构**（见下方分节）；AI 必须按当前平台读对应节，
  其余步骤通用。

## 你的任务：完成环境安装

用户安装本插件后（市场安装只放入文档骨架），按以下步骤装 Node。每步都有验证点，
失败时按对应 fallback 走。

### 第 1 步：确认插件目录与已装检测

- 安装根目录：
  - **Windows**：`%APPDATA%/com.claudecode.gui/plugins/nodejs/`
  - **macOS**：`~/Library/Application Support/com.claudecode.gui/plugins/nodejs/`
  - **Linux**：`~/.config/com.claudecode.gui/plugins/nodejs/`
- 已装检测（存在则跳过下载，直接做第 4 步验证）：
  - **Windows**：`runtime/node.exe`
  - **macOS/Linux**：`runtime/bin/node`

### 第 2 步：确定版本与架构

- 版本：**当前 LTS**（不钉死）。查 `https://nodejs.org/dist/index.json` 的最新 LTS 行
  （`lts` 字段非 false 的最大版本）；查不到时用已知稳定 LTS（如 v22.x）。
- 架构：`process.arch`（你所在进程）——按平台映射：
  - Windows：`x64` → `win-x64` / `arm64` → `win-arm64`
  - macOS：`x64` → `darwin-x64` / `arm64` → `darwin-arm64`
  - Linux：`x64` → `linux-x64` / `arm64` → `linux-arm64`

### 第 3 步：下载（端点 fallback 链，按顺序尝试）

对每个端点：下载 `node-v<版本>-<平台>-<架构>.zip`（**Windows**）或
`.tar.gz`（**macOS/Linux**——官方发行包只提供 tar 格式）。
**每次下载限时 120s**，失败信号 = HTTP 非 200 / 连接超时 / 文件 < 10MB（截断包）→ 立即切换下一级。

1. **npmmirror（国内首选）**：`https://registry.npmmirror.com/-/binary/node/latest-v22.x/<文件名>`
2. **华为云镜像（国内备选）**：`https://mirrors.huaweicloud.com/nodejs/v<版本>/<文件名>`
3. **官方（兜底）**：`https://nodejs.org/dist/v<版本>/<文件名>`

下载到临时目录（Windows `%TEMP%/nodejs-plugin-download/`；macOS/Linux `/tmp/nodejs-plugin-download/`）。
**tar.gz 用 `tar -xzf` 解压，不是 zipfile。**

### 第 4 步：解压 + 拍平 + 验证

- 解压临时目录 → 解出 `node-v<版本>-<平台>-<架构>/` **内层目录**；
- 把**内层目录的内容**（不是目录本身）移入 `plugins/nodejs/runtime/`——
  多套一层是最常见安装失败原因，装完务必确认。
- **拍平后的结构（按平台）**：
  - **Windows**：`runtime/` 下直接是 `node.exe`、`npm.cmd`、`node_modules/`
  - **macOS/Linux**：`runtime/` 下是 `bin/`（node/npm）、`lib/`、`include/`、`share/`（官方 tar 布局）
- 验证：
  - **Windows**：`runtime/node.exe --version`
  - **macOS/Linux**：`runtime/bin/node --version`（注意是 `bin/` 前缀）
  输出 `v<版本>` 即成功。清理临时文件。

### 第 5 步：上报就绪状态

验证通过后调用 MCP 工具上报（GUI 重启后状态清空，需重新验证再报）：

```
plugin_set_status(name="nodejs", status="ready", detail={
  "version": "v22.x.x",
  "arch": "<win-x64|darwin-arm64|linux-x64|...>",
  "endpoint": "<实际命中的下载端点>",
  "verify": "node --version → v22.x.x"
})
```

下载/解压失败但目录已部分就位 → 报 `not_ready` + detail 写明卡在哪一步；
完全失败 → 报 `error` + detail 写明原因。

### 第 6 步：告知用户生效范围（⚠️ 平台差异要点）

- **Windows**：当前 AI 会话 Bash 直接 `node`（GUI 推送 PATH→B 通道）；新会话启动自扫（A 通道）。
- **macOS/Linux**：当前 PATH 聚合注入的是 **runtime/ 根目录**（不是 `runtime/bin/`），
  Bash 里直接 `node` 找不到——**用绝对路径调用**：`<runtime>/bin/node --version`，
  或依赖方声明进程时 command 直接用绝对路径。这是已知限制，如实告知用户，
  不要声称"直接 node 可用"。
- 若当前会话 Bash 里 node 仍不可用：先重试一次，仍不行则告知用户重启会话/引擎后生效。

## 故障模式与诊断

### 1. 「装了但 AI Bash 里 node 不可用」
- 先 `plugin_list` 看插件在列且 `enabled: true`、`aiStatus` 是否为 `ready`；
- `aiStatus` 缺失 → 环境安装未完成或未上报——从第 1 步重走；
- **Windows**：`runtime/node.exe` 存在但 Bash 不可用 → 当前会话可能是推送前启动的旧引擎——
  让用户重启会话（通道 A 兜底会在启动时注册）。
- **macOS/Linux**：`runtime/bin/node` 存在但 `node` 不可用 → **预期行为**（见第 6 步），
  改用绝对路径；若绝对路径也不可执行 → 检查 `chmod +x`（tar 解压可能丢执行位）。

### 2. 「下载一直失败」
- 按 fallback 链逐级试过没有？三端点都失败通常是网络层问题（代理/防火墙）；
- 检查临时目录有无残留截断文件（< 10MB）→ 清掉重试；
- 让用户手动下载并告知路径 → 你来解压拍平（下载是唯一允许用户介入的步骤）。

### 3. 「解压后 node 不在 runtime/ 根」
- **Windows**：多套了一层目录（`runtime/node-v22.x-win-x64/node.exe`）→ 把内层内容上移一层。
- **macOS/Linux**：`runtime/bin/node` 不在 → 检查是否多套了一层（应解压出
  `bin/`、`lib/`、`include/` 等目录直接在 runtime/ 下）。

### 4. 「插件进程里 node 可用性异常」
- 依赖插件的进程 PATH 由平台在 spawn 时注入（前置段）——`plugin_get` 看该插件
  processes 声明；进程 error 时看 Worker 面板状态与日志。

### 5. 「卸载被拒绝」
- 卸载 nodejs 前必须先卸载依赖它的插件（GUI 会列出清单）——这是防呆设计不是故障。

## 日志与状态位置

- 安装目录：`%APPDATA%/com.claudecode.gui/plugins/nodejs/`（Win）/
  `~/Library/Application Support/com.claudecode.gui/plugins/nodejs/`（mac）/
  `~/.config/com.claudecode.gui/plugins/nodejs/`（Linux）
- 运行时就绪标记：`plugin_get name=nodejs` 的 `aiStatus` 字段（内存态，GUI 重启清空）
- 下载临时区：`%TEMP%/nodejs-plugin-download/`（Win）/ `/tmp/nodejs-plugin-download/`（unix）——装完即清

## 配置依赖

- dependencies: 无
- installType: ai-guided——**卸载指导**：直接调 `plugin_uninstall`（用户同意后），
  Node 运行时在 runtime/ 内随目录一起删除，无系统残留
- platforms: ["windows","macos","linux"]
- 版本兼容：跟随 LTS；本插件不管理多版本（将来如需，按 nodejs20/nodejs22 拆分插件）
