# Node.js 运行时环境 (nodejs)

GUI 插件生态的**基础设施插件**——为插件后台进程与 AI 的 Bash 提供 Node.js LTS 运行时。

## 它做什么

| 项 | 说明 |
|----|------|
| 形态 | `ai-guided`——包里不含 Node 本体，安装后由 **AI 按排查文档引导**下载 |
| 安装位置 | 本插件目录内的 `runtime/`（单版本平铺） |
| PATH | **仅程序内部**——插件进程与 AI 会话自动可用 `node`，系统环境变量零改动 |
| 卸载 | 卸载本插件 = 连带删除 Node，卸载前需先卸载依赖它的插件 |

## 使用

1. 插件市场安装本插件（只是放入文档骨架）
2. 对 AI 说：**"帮我完成 nodejs 插件的环境安装"**——AI 会读取 AI_NOTES.md，检测架构、下载 Node LTS（含国内镜像 fallback）、解压验证、上报就绪状态
3. 完成后：AI 会话里 `node --version` 直接可用；依赖插件声明 `"command": "node"` 的后台进程直接启动

## 给插件作者

依赖本环境：manifest 里声明 `"dependencies": ["nodejs"]`，进程命令写 `"command": "node"`（无需写绝对路径——平台已把 runtime 注册进程序内部 PATH）。
